# Промпт: SignFinder v1.7 — Часть 1/3 — Core модули

Проект: SignFinder MVP — система автоподписания договоров PDF/DOCX.
Стек: Python, Streamlit, PyMuPDF (fitz), Claude API (claude-sonnet-4-6), GCP Cloud Run, GCS.
Версия в продакшене: v1.6. Версия для разработки: v1.7.

Это **часть 1 из 3**. Здесь — только новые core модули. UI и удаление страниц в частях 2 и 3.

## Где код

Все файлы проекта лежат в `/mnt/project/` — используй `view` для чтения перед правкой.

Структура core сейчас:
```
/mnt/project/core/
├── auth.py              # check_access_code
├── storage.py           # GCS/local switch
├── parser.py            # PDF/DOCX → fitz.Document
├── finder.py            # regex-поиск + умный bbox
├── validator.py         # LLM-валидация
├── party_resolver.py    # LLM-резолвер стороны
├── pattern_extractor.py # LLM-синтез regex
├── overlay.py           # наложение PNG подписи
├── preview.py           # рендер страниц
├── llm_finder.py        # LLM-fallback
├── language_detector.py
└── corrector.py
```

## Главные принципы v1.7 (контекст)

### Принцип якорения

Подпись в SignFinder **всегда привязана к тексту документа** — слову, фразе или линии подчёркиваний. UI не позволяет ставить подпись в пустую область страницы. Fallback на абсолютные координаты **отсутствует**.

### Унификация: всё через текстовые якоря

В `DocumentTemplate` нет `regex_patterns` и `manual_coordinates` отдельно. Есть **единый список `anchors`**, где каждый якорь имеет поле `added_by`:
- `auto_regex` — якорь создан из regex-паттерна автоматически
- `manual_click` — якорь создан из клика оператора

Логика применения одинакова.

### Алгоритм клик → текстовый якорь (4 уровня)

```
Уровень 1 — Текст в радиусе 30pt от клика
Уровень 2 — Текст в той же строке (горизонтальная полоса ±10pt по y)
Уровень 3 — Текст в области страницы (радиус ~200pt)
Уровень 4 — Линия подчёркиваний (паттерн _{5,})

Нет якоря → возврат None
```

## Задачи части 1

Создать четыре новых модуля и расширить один существующий.

### Модуль 1: `core/anchor_builder.py` (НОВЫЙ)

**Назначение:** конвертировать клик `(page_idx, x, y)` в текстовый якорь.

**Структура TextAnchor:**

```python
from typing import Optional, Literal
from dataclasses import dataclass, field

@dataclass
class TextAnchor:
    id: str                          # uuid4
    anchor_type: Literal["text_proximity", "underline_line"]
    anchor_level: int                # 1-4
    anchor_text: str                 # точный текст из документа
    position: Literal["right", "left", "below", "above", "on"]
    offset_pt: float                 # смещение от anchor_text до места подписи
    generated_pattern: str           # regex для finder.py
    context_before: str              # ~50 символов до якоря для дезамбигуации
    context_after: str               # ~50 символов после
    page_hint: str                   # "first" | "last" | "any" | str(page_idx)
    added_by: Literal["auto_regex", "manual_click"]
    added_at: str                    # ISO timestamp
    bbox: tuple[float, float, float, float]  # где встанет подпись (x0, y0, x1, y1)
```

**Публичный API:**

```python
def build_anchor_from_click(
    doc,                # fitz.Document
    page_idx: int,
    click_x: float,
    click_y: float,
    language: str,
    signature_height_pt: float = 30.0
) -> Optional[TextAnchor]:
    """
    Превращает клик в TextAnchor через 4-уровневый алгоритм.
    Возвращает None если не удалось построить якорь (клик в пустоту).
    """

def build_anchor_from_regex_match(
    pattern: str,
    match_text: str,
    match_bbox: tuple[float, float, float, float],
    page_idx: int,
    language: str,
    context_before: str = "",
    context_after: str = ""
) -> TextAnchor:
    """
    Превращает найденный regex-матч в TextAnchor.
    Используется при автоматическом поиске через finder.py.
    """

def has_anchor_at(
    doc,
    page_idx: int,
    x: float,
    y: float
) -> bool:
    """
    Проверяет можно ли построить якорь в точке (для UI hover-проверки).
    Дешёвая операция — быстро возвращает bool.
    Не строит полный якорь, только проверяет наличие текста в радиусе.
    """
```

**Логика build_anchor_from_click:**

```python
def build_anchor_from_click(doc, page_idx, click_x, click_y, language, signature_height_pt=30.0):
    page = doc[page_idx]
    
    # Уровень 1 — текст в радиусе 30pt
    blocks_near = _find_text_blocks_in_radius(page, click_x, click_y, radius=30)
    if blocks_near:
        return _build_anchor_level_1(blocks_near, click_x, click_y, language, page_idx, doc, signature_height_pt)
    
    # Уровень 2 — текст в той же строке
    blocks_same_row = _find_text_blocks_same_row(page, click_x, click_y, tolerance=10)
    if blocks_same_row:
        return _build_anchor_level_2(blocks_same_row, click_x, click_y, language, page_idx, doc, signature_height_pt)
    
    # Уровень 3 — текст в области страницы (радиус 200pt)
    blocks_in_area = _find_text_blocks_in_radius(page, click_x, click_y, radius=200)
    if blocks_in_area:
        return _build_anchor_level_3(blocks_in_area, click_x, click_y, language, page_idx, doc, signature_height_pt)
    
    # Уровень 4 — линия подчёркиваний
    underline = _find_nearest_underline(page, click_x, click_y, max_distance=50)
    if underline:
        return _build_anchor_level_4(underline, click_x, click_y, language, page_idx, doc, signature_height_pt)
    
    return None
```

**Хелперы для реализации (внутренние):**

- `_find_text_blocks_in_radius(page, x, y, radius)` — через `page.get_text("blocks")`, фильтр по distance от центра bbox
- `_find_text_blocks_same_row(page, x, y, tolerance)` — то же, но фильтр по y-координате
- `_find_nearest_underline(page, x, y, max_distance)` — поиск строк с подчёркиваниями через regex `_{5,}` или `\.{5,}` в извлечённом тексте
- `_generate_pattern_for_anchor(anchor_text, position, language)` — генерация regex по тексту-якорю и его положению относительно подписи
- `_extract_context(page, anchor_bbox, before=50, after=50)` — извлечение контекста до и после anchor_text

**Замечания по реализации:**

- Используй `uuid.uuid4().hex` для генерации id якоря
- Используй `datetime.now(timezone.utc).isoformat()` для added_at
- `signature_height_pt=30.0` — фиксированная высота подписи как в существующем `overlay.py`
- bbox якоря рассчитывается исходя из положения текста-якоря и направления (справа/слева/снизу/сверху/на)

### Модуль 2: `core/fingerprint.py` (НОВЫЙ)

**Назначение:** вычисление fingerprint документа для будущего matching шаблонов (полный matching будет в v1.8, fingerprint считаем уже при сохранении в v1.7).

**API:**

```python
from typing import Optional

def compute_fingerprint(doc, language: str) -> dict:
    """
    Возвращает:
    {
        "page_count": int,
        "total_chars": int,
        "chars_per_page": list[int],
        "header_simhash": str,       # SimHash шапки (find_header_page)
        "section_titles": list[str], # заголовки разделов
        "language": str
    }
    """

def find_header_page(doc, language: str) -> int:
    """
    Возвращает индекс страницы с реальной преамбулой (не титульный лист).
    
    Алгоритм:
    1. Проверяем первые 3 страницы документа
    2. Страница считается шапкой если:
       - >= 300 значимых символов
       - И содержит хотя бы один маркер преамбулы для языка
    3. Маркеры преамбулы:
       ru: ["именуем", "в лице", "настоящ", "заключил", "с одной стороны"]
       en: ["hereinafter", "represented by", "between", "agreed as follows"]
       pl: ["umow", "zawart", "reprezentowan", "zwan"]
    4. Fallback — первая страница с достаточным объёмом текста
    5. Если ничего не нашли — возврат 0
    """

def compute_header_simhash(doc, page_idx: int) -> str:
    """SimHash текста шапки. Использует библиотеку simhash."""

def extract_section_titles(doc) -> list[str]:
    """
    Извлекает заголовки разделов через regex:
    - "^\d+\.\s+[А-ЯA-Z]" — нумерованные пункты
    - "РАЗДЕЛ|ПРИЛОЖЕНИЕ|АКТ|СТАТЬЯ"
    - "Section|Annex|Appendix|Schedule|Article"
    - "Część|Załącznik|Rozdział|Artykuł"
    """
```

**Зависимости:** `simhash>=2.1.2` (добавить в requirements.txt).

### Модуль 3: `core/template_storage.py` (НОВЫЙ)

**Назначение:** CRUD для `DocumentTemplate` в GCS коллекции `gs://signfinder-config/templates/`.

**Структура DocumentTemplate:**

```python
from dataclasses import dataclass, field, asdict
from typing import Optional, Literal

@dataclass
class DocumentTemplate:
    template_id: str                 # uuid
    name: str
    language: str
    created_at: str
    created_by: Literal["pipeline_auto_1", "manual_enrichment"]
    
    fingerprint: dict                # будет использоваться в v1.8
    anchors: list                    # list[TextAnchor], сериализуется как list[dict]
    synonyms_used: dict              # legal_entity, roles, signer
    
    usage_stats: dict = field(default_factory=lambda: {
        "times_applied": 0,
        "times_confirmed": 0,
        "times_rejected": 0,
        "last_used": None
    })
```

**Файловое представление:** один JSON файл на шаблон в GCS, имя `{template_id}.json`. Шаблоны живут в `gs://signfinder-config/templates/` (или `config/templates/` локально).

**API:**

```python
def save_template(template: DocumentTemplate) -> str:
    """Сохраняет шаблон в GCS/local, возвращает template_id."""

def load_template(template_id: str) -> Optional[DocumentTemplate]:
    """Читает шаблон по ID. None если не найден."""

def list_templates(language: Optional[str] = None) -> list[DocumentTemplate]:
    """Список всех шаблонов, опционально с фильтром по языку."""

def delete_template(template_id: str) -> bool:
    """Удаляет шаблон. Бэкап в _archive/ перед удалением."""

def generate_template_name(language: str, synonyms: Optional[dict] = None) -> str:
    """
    Авто-генерация имени по схеме:
    pipelineAuto1_YYYY-MM-DD_HHMM_<язык>
    
    Если переданы synonyms — может включить юрлицо или роль в имя:
    pipelineAuto1_2026-05-20_1430_ru_Аренда
    """
```

**Использование:** через существующий `core/storage.py` для GCS/local switch. Бэкапы по аналогии с существующей логикой для `parties.json`.

### Модуль 4: Расширение `core/finder.py`

В существующий `finder.py` (без слома текущей логики) добавь функции для работы с якорями:

```python
def apply_template_anchors(doc, template) -> list:
    """
    Применяет якоря из шаблона к новому документу.
    Для каждого якоря — ищет его generated_pattern в тексте,
    с учётом context_before/context_after для дезамбигуации.
    Возвращает list[SignMatch] с bbox.
    
    Используется в v1.8 при матчинге шаблонов. В v1.7 — готова к использованию.
    """

def regex_match_to_anchor(match, page_idx: int, language: str) -> "TextAnchor":
    """
    Конвертирует существующий regex-матч (SignMatch или подобный)
    в TextAnchor с added_by="auto_regex".
    
    Используется в pipelineAuto1 при сохранении результата в шаблон.
    """
```

Импорт TextAnchor — из `core.anchor_builder`.

### Что обязательно сделать дополнительно

1. **Обновить `requirements.txt`** — добавить `simhash>=2.1.2`
2. **Не трогать существующие функции** в `finder.py`, `validator.py`, `party_resolver.py`, `pattern_extractor.py`, `parser.py` — расширение только через новые функции
3. **Не трогать GCS schema существующих файлов** — `parties.json`, `signer_profile.json`, `markers.json`, `signature.png` остаются как есть
4. **Логирование ошибок через stderr** — никаких print, только `sys.stderr.write()` или `logging`

## Формат выдачи

Для каждого нового/изменённого файла:

```
## Путь: /mnt/project/core/anchor_builder.py
## Статус: НОВЫЙ (v1.7)

<полный код файла>
```

или

```
## Путь: /mnt/project/core/finder.py
## Статус: РЕДАКТИРУЕМ (добавление функций apply_template_anchors и regex_match_to_anchor)

<полный код файла>
```

**Обязательно указывай статус — НОВЫЙ или РЕДАКТИРУЕМ.**
Не выводи файлы которые не трогал.

## Стиль кода

- Короткие функции, docstring где нужен контекст
- Типы через `typing` для публичных функций
- Обработка ошибок через try/except с логированием в stderr
- Без магии, прямой код

## После завершения части 1

Сообщи мне результат — что сделал, какие модули появились, есть ли вопросы или проблемы. После моего подтверждения перейдём к части 2 (UI страницы автоподписания).

## Формат запросов

Когда пишешь — кратко, по делу, циничный delivery-manager тон. Без "отличной работы" и "всё готово к использованию". Если нужна правка от меня — конкретно что и зачем.

---

**Задача:** реализация части 1/3 — core модули для anchor-based templates.
**Жду уточняющих вопросов или сразу кода.**
