# Промпт: SignFinder v1.7 — Часть 3/3 — Авто-подписание с пагинацией и drag&drop

Проект: SignFinder MVP — система автоподписания договоров PDF/DOCX.
Стек: Python, Streamlit, PyMuPDF (fitz), Claude API, GCP Cloud Run, GCS.
Версия в продакшене: v1.6. Версия для разработки: v1.7.

Это **часть 3 из 3** — самая большая. Здесь — полная переработка страницы автоподписания с пагинацией, режимом ручной доразметки, canvas с drag&drop и сохранением шаблона.

Части 1 (core модули) и 2 (dashboard) уже выполнены.

## Что должно существовать после частей 1-2

```
/mnt/project/
├── app.py                          # dashboard (после части 2)
├── core/
│   ├── anchor_builder.py           # часть 1
│   ├── template_storage.py         # часть 1
│   ├── fingerprint.py              # часть 1
│   ├── finder.py                   # расширен в части 1
│   └── ... (остальные модули как были)
└── pages/
    ├── 2___Шаблоны.py              # без изменений
    ├── 4___Настройки.py            # без изменений
    ├── 5_🤖_Авто_подписание.py     # текущая версия, будет полностью переработана
    └── 6___Документация.py         # часть 2
```

Если что-то из части 1 или 2 ещё не на месте — попроси меня поставить файлы перед началом.

## Контекст

`pages/5_🤖_Авто_подписание.py` сейчас реализует pipelineAuto1 — автоматический поиск мест подписи через regex, без возможности доразметки. В v1.7 страница расширяется:

1. **Пагинация** — листание по страницам PDF через `[- N +]`
2. **Чекбоксы найденных мест** — над превью текущей страницы
3. **Режим ручной доразметки** — клик добавляет якорь, drag перемещает, удаление
4. **Сохранение шаблона** — все якоря (auto + manual) попадают в `DocumentTemplate`

## Главная задача части 3

### Полная переработка `pages/5_🤖_Авто_подписание.py`

**UX-флоу:**

```
1. Загрузка документа PDF/DOCX (как в текущей версии)

2. Запуск pipelineAuto1 (существующая логика — определение языка, синонимов, regex-поиск)
   После обработки:
   - Каждый найденный SignMatch конвертируется в TextAnchor с added_by="auto_regex"
     через core.finder.regex_match_to_anchor() (создан в части 1)
   - Список якорей сохраняется в st.session_state["all_anchors"]
   - Вычисляется fingerprint документа через core.fingerprint.compute_fingerprint()
   - Сохраняется в st.session_state["fingerprint"]

3. Превью с пагинацией:
   
   ────────────────────────────────────
   2️⃣ ПРЕВЬЮ И ДОРАЗМЕТКА
   
   Номер страницы:  [-]  [3]  [+]   (стр. 3 из 12)
   
   Места подписи на стр. 3:
   ☑ #1 — auto (Уровень 1) | якорь: "Арендатор:"
   ☑ #2 — auto (Уровень 1) | якорь: "Подпись:"
   ☑ #3 — manual (Уровень 1) | якорь: "М.П."
   
   ┌──────────────────────────────┐
   │  [PDF Canvas рендер стр. 3]  │
   │   с наложенными подписями    │
   │   и интерактивностью         │
   └──────────────────────────────┘
   
   Режим: [👁 Просмотр] [✏ Добавить место подписи]
   ────────────────────────────────────

4. В режиме "Добавить место подписи":
   - Mousemove → полупрозрачная рамка размера подписи следует за курсором
   - В пустой области без якоря → рамка красная/перечёркнутая,
     подсказка "Кликните над текстом или подчёркиваниями"
   - Клик в валидной зоне → 
     - вызов core.anchor_builder.build_anchor_from_click(doc, page_idx, x, y, language)
     - если якорь построен → подпись фиксируется в позиции рамки
     - якорь добавляется в st.session_state["all_anchors"] с added_by="manual_click"
   - Drag размещённой подписи →
     - подпись перетаскивается на canvas
     - якорь пересчитывается через build_anchor_from_click() с новыми координатами
     - если в новой точке нет якоря → подпись возвращается на старое место + предупреждение
   - Клик по подписи + кнопка "Удалить" → удаление якоря из сессии

5. Общие действия (под превью, видны всегда):
   
   Всего мест: {auto_count} auto + {manual_count} manual = {total}
   
   [⬇ Скачать подписанный PDF]
   
   ───────────────────────────────
   Имя шаблона: [pipelineAuto1_2026-05-20_1430_ru______]
   [💾 Сохранить шаблон]
       - Кнопка ВСЕГДА доступна
       - Если есть manual якоря — кнопка ярче (filled style)
       - Если только auto — стандартная (можно не сохранять)
   ───────────────────────────────
```

### Реализация drag&drop через streamlit-drawable-canvas

**Зависимость:** `streamlit-drawable-canvas>=0.9.0` (добавить в `requirements.txt`).

Документация: https://github.com/andfanilo/streamlit-drawable-canvas

**Ключевые идеи:**

- Канвас отображает текущую страницу PDF как `background_image`
- Размещённые подписи передаются как `initial_drawing` — список объектов типа "rect"
- Режим `drawing_mode="transform"` позволяет перетаскивать существующие объекты
- Режим `drawing_mode="rect"` — добавление новых (но мы это перехватываем через `objects_to_json` и обрабатываем сами)

**Псевдокод интеграции:**

```python
from streamlit_drawable_canvas import st_canvas
import fitz
from PIL import Image
import io

# === Подготовка фона ===
doc = st.session_state["doc"]  # fitz.Document
page_idx = st.session_state["current_page"]
page = doc[page_idx]

# Рендерим страницу в PIL Image
pix = page.get_pixmap(matrix=fitz.Matrix(2.0, 2.0))  # 2x для качества
page_img = Image.open(io.BytesIO(pix.tobytes("png")))
img_width, img_height = page_img.size

# === Подготовка объектов для канваса ===
# Берём якоря для текущей страницы
all_anchors = st.session_state["all_anchors"]
anchors_on_page = [a for a in all_anchors if str(a.page_hint) == str(page_idx)]

# Масштабирование: PDF координаты в pt → пиксели канваса
# pixmap 2x — значит pixel = pt * 2
scale = 2.0

initial_objects = []
for anchor in anchors_on_page:
    bbox_px = [coord * scale for coord in anchor.bbox]
    initial_objects.append({
        "type": "rect",
        "left": bbox_px[0],
        "top": bbox_px[1],
        "width": bbox_px[2] - bbox_px[0],
        "height": bbox_px[3] - bbox_px[1],
        "fill": "rgba(0, 128, 0, 0.3)" if anchor.added_by == "auto_regex" else "rgba(255, 165, 0, 0.3)",
        "stroke": "green" if anchor.added_by == "auto_regex" else "orange",
        "strokeWidth": 2,
        "id": anchor.id  # для дальнейшего матчинга
    })

# === Канвас ===
mode = st.session_state.get("canvas_mode", "view")  # "view" | "add"

canvas_result = st_canvas(
    fill_color="rgba(0, 128, 0, 0.3)",
    stroke_width=2,
    stroke_color="green",
    background_image=page_img,
    update_streamlit=True,
    width=img_width,
    height=img_height,
    drawing_mode="transform" if mode == "view" else "rect",
    initial_drawing={"version": "4.4.0", "objects": initial_objects},
    key=f"canvas_page_{page_idx}_{mode}",  # ключ меняется при смене режима
)

# === Обработка изменений ===
if canvas_result.json_data is not None:
    new_objects = canvas_result.json_data.get("objects", [])
    _handle_canvas_changes(new_objects, anchors_on_page, page_idx, scale, doc)
```

**Логика `_handle_canvas_changes`:**

```python
def _handle_canvas_changes(new_objects, current_anchors, page_idx, scale, doc):
    """
    Обрабатывает изменения от canvas:
    - Новые прямоугольники (только что нарисованные) → построить якорь, добавить
    - Перемещённые прямоугольники → пересчитать якорь по новым координатам
    - Удалённые прямоугольники → удалить якорь из сессии
    """
    
    # Сопоставление по id
    new_by_id = {obj.get("id"): obj for obj in new_objects if obj.get("id")}
    current_by_id = {a.id: a for a in current_anchors}
    
    # Удалённые
    deleted_ids = set(current_by_id.keys()) - set(new_by_id.keys())
    for aid in deleted_ids:
        st.session_state["all_anchors"] = [a for a in st.session_state["all_anchors"] if a.id != aid]
    
    # Перемещённые (id есть в обоих, но координаты разные)
    for aid, new_obj in new_by_id.items():
        if aid in current_by_id:
            old_anchor = current_by_id[aid]
            new_left_pt = new_obj["left"] / scale
            new_top_pt = new_obj["top"] / scale
            
            # Если координаты изменились
            if abs(new_left_pt - old_anchor.bbox[0]) > 1 or abs(new_top_pt - old_anchor.bbox[1]) > 1:
                # Пересчёт якоря по новому центру
                center_x_pt = new_left_pt + (new_obj["width"] / scale) / 2
                center_y_pt = new_top_pt + (new_obj["height"] / scale) / 2
                
                new_anchor = build_anchor_from_click(
                    doc, page_idx, center_x_pt, center_y_pt, 
                    st.session_state["language"]
                )
                
                if new_anchor:
                    # Заменяем старый якорь новым
                    new_anchor.id = old_anchor.id  # сохраняем тот же id для UI
                    st.session_state["all_anchors"] = [
                        new_anchor if a.id == aid else a 
                        for a in st.session_state["all_anchors"]
                    ]
                # Если новая точка не валидна — UI должен показать предупреждение
                # Технически canvas вернёт объект в старую позицию через rerun
    
    # Новые (только если в режиме "add" — но st-canvas в режиме rect сам обработает)
    # Новые прямоугольники не имеют id из current_by_id — добавляем
    for obj in new_objects:
        if not obj.get("id"):
            # Это новый прямоугольник от пользователя
            center_x_pt = (obj["left"] + obj["width"] / 2) / scale
            center_y_pt = (obj["top"] + obj["height"] / 2) / scale
            
            new_anchor = build_anchor_from_click(
                doc, page_idx, center_x_pt, center_y_pt,
                st.session_state["language"]
            )
            
            if new_anchor:
                st.session_state["all_anchors"].append(new_anchor)
            else:
                st.warning("Не удалось построить якорь в этой точке. Кликните над текстом или подчёркиваниями.")
```

### Чекбоксы найденных мест над превью

Для текущей страницы — список якорей с чекбоксами:

```python
anchors_on_page = [a for a in st.session_state["all_anchors"] if str(a.page_hint) == str(current_page)]

st.write(f"Места подписи на стр. {current_page + 1}:")

for i, anchor in enumerate(anchors_on_page):
    col1, col2 = st.columns([1, 9])
    
    with col1:
        enabled_key = f"anchor_enabled_{anchor.id}"
        if enabled_key not in st.session_state:
            st.session_state[enabled_key] = True
        
        st.session_state[enabled_key] = st.checkbox(
            "", 
            value=st.session_state[enabled_key],
            key=f"cb_{anchor.id}"
        )
    
    with col2:
        source_label = "auto" if anchor.added_by == "auto_regex" else "manual"
        st.caption(f"#{i+1} — {source_label} (Уровень {anchor.anchor_level}) | якорь: \"{anchor.anchor_text[:30]}\"")
```

Чекбоксы влияют только на финальное наложение подписи и скачивание — но НЕ удаляют якорь из шаблона.

### Сохранение шаблона

```python
def save_current_template():
    """Сохраняет текущее состояние сессии как DocumentTemplate."""
    from core.template_storage import save_template, generate_template_name, DocumentTemplate
    from core.fingerprint import compute_fingerprint
    import uuid
    from datetime import datetime, timezone
    
    doc = st.session_state["doc"]
    language = st.session_state["language"]
    synonyms = st.session_state.get("synonyms_found", {})
    anchors = st.session_state["all_anchors"]
    
    has_manual = any(a.added_by == "manual_click" for a in anchors)
    created_by = "manual_enrichment" if has_manual else "pipeline_auto_1"
    
    template_name = st.session_state.get("template_name_input") or generate_template_name(language, synonyms)
    
    template = DocumentTemplate(
        template_id=uuid.uuid4().hex,
        name=template_name,
        language=language,
        created_at=datetime.now(timezone.utc).isoformat(),
        created_by=created_by,
        fingerprint=compute_fingerprint(doc, language),
        anchors=[asdict(a) for a in anchors],  # сериализация dataclass
        synonyms_used=synonyms,
    )
    
    template_id = save_template(template)
    st.success(f"Шаблон сохранён: {template_name} (id: {template_id})")
```

UI для сохранения:

```python
st.markdown("---")
st.subheader("💾 Сохранение шаблона")

has_manual = any(a.added_by == "manual_click" for a in st.session_state.get("all_anchors", []))

default_name = generate_template_name(
    st.session_state.get("language", "ru"),
    st.session_state.get("synonyms_found")
)
template_name = st.text_input("Имя шаблона", value=default_name, key="template_name_input")

button_label = "💾 Сохранить шаблон (рекомендуется)" if has_manual else "💾 Сохранить шаблон"
button_type = "primary" if has_manual else "secondary"

if st.button(button_label, type=button_type):
    save_current_template()
```

### Наложение подписи и скачивание

Использовать существующий `core/overlay.py` — он работает с координатами bbox. Применить только к тем якорям, у которых чекбокс включён.

```python
def build_signed_pdf():
    """Накладывает подпись на все включённые якоря и возвращает bytes готового PDF."""
    from core.overlay import apply_signature
    
    enabled_anchors = [
        a for a in st.session_state["all_anchors"]
        if st.session_state.get(f"anchor_enabled_{a.id}", True)
    ]
    
    # Конвертация anchor.bbox → формат подходящий для apply_signature
    signatures = []
    for anchor in enabled_anchors:
        signatures.append({
            "page": int(anchor.page_hint) if anchor.page_hint.isdigit() else 0,
            "bbox": anchor.bbox
        })
    
    signed_pdf_bytes = apply_signature(
        doc=st.session_state["doc"],
        signature_png=st.session_state["signature_png"],
        signatures=signatures
    )
    
    return signed_pdf_bytes
```

UI для скачивания:

```python
if st.button("⬇ Скачать подписанный PDF", type="primary"):
    pdf_bytes = build_signed_pdf()
    st.download_button(
        "Сохранить файл",
        data=pdf_bytes,
        file_name=f"signed_{st.session_state['filename']}.pdf",
        mime="application/pdf"
    )
```

## Известные сложности и подсказки

### Сложность 1: Координаты PDF vs Canvas

PyMuPDF использует **points (pt)** — 72 pt = 1 inch. Canvas streamlit-drawable работает в **пикселях**.

При рендере страницы через `page.get_pixmap(matrix=fitz.Matrix(2.0, 2.0))` — масштаб 2x, значит 1 pt = 2 px.

Все конвертации:
- `pixel = pt * 2.0` (если scale=2.0)
- `pt = pixel / 2.0`

### Сложность 2: PIL.Image для background_image

```python
pix = page.get_pixmap(matrix=fitz.Matrix(2.0, 2.0))
img_bytes = pix.tobytes("png")
page_img = Image.open(io.BytesIO(img_bytes))
```

### Сложность 3: Перерендер canvas при смене страницы

Используй уникальный `key` для канваса, включающий номер страницы и режим:
```python
key=f"canvas_page_{page_idx}_{mode}"
```

Это заставит Streamlit пересоздать компонент при смене страницы — иначе будут видны якоря с предыдущей страницы.

### Сложность 4: Поле page_hint в TextAnchor

В части 1 поле — строка ("first" | "last" | "any" | str(page_idx)). При работе с конкретным якорем удобнее иметь индекс. Используй:

```python
def get_anchor_page_idx(anchor, doc):
    """Возвращает конкретный индекс страницы для якоря."""
    if anchor.page_hint == "first":
        return 0
    if anchor.page_hint == "last":
        return doc.page_count - 1
    if anchor.page_hint.isdigit():
        return int(anchor.page_hint)
    return None  # "any" — не определено
```

### Сложность 5: Если streamlit-drawable-canvas не работает

Если по каким-то причинам компонент глючит — **fallback**:
1. Сохраняй якоря только через клик (без drag&drop)
2. Удаление через отдельную кнопку рядом с чекбоксом
3. Для добавления нового якоря — использовать `streamlit-image-coordinates` (он только клики)

В этом случае **сообщи мне** и я приму решение, переключаться ли на упрощённую версию или искать обходной путь для drag&drop.

## Зависимости

В `requirements.txt`:
```
streamlit-drawable-canvas>=0.9.0
```

(simhash уже должен быть из части 1)

## Формат выдачи

```
## Путь: /mnt/project/pages/5_🤖_Авто_подписание.py
## Статус: РЕДАКТИРУЕМ (полная переработка под v1.7 с пагинацией и drag&drop)

<полный код файла>
```

```
## Путь: /mnt/project/requirements.txt
## Статус: РЕДАКТИРУЕМ (добавление streamlit-drawable-canvas)

<полный код файла>
```

## Стиль кода

- Streamlit-friendly: `st.session_state` для всего что должно жить между rerun
- Короткие функции, выделяй хелперы
- Без магии, прямой код
- Логирование ошибок в stderr (`sys.stderr.write` или `logging`)
- Обработка ошибок через try/except — если что-то падает, страница не должна крашнуться полностью

## После завершения

Сообщи результат и любые проблемы. Особенно важно:
- Удалось ли встроить streamlit-drawable-canvas в режиме transform
- Корректно ли работает пересчёт якорей при drag
- Есть ли визуальные баги с пагинацией и сменой страниц

Тестирование на реальных документах будет делать пользователь вручную.

## Формат запросов

Когда пишешь — кратко, по делу, циничный delivery-manager тон. Без "отличной работы". Если что-то не получается — сообщай сразу с предложениями альтернативы.

---

**Задача:** реализация части 3/3 — переработка страницы Авто-подписание с drag&drop.
**Жду уточняющих вопросов или сразу кода.**
