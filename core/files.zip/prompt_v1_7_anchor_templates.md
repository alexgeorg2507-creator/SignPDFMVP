# Промпт: SignFinder v1.7 — Гибридные шаблоны через текстовые якоря

Проект: SignFinder MVP — система автоподписания договоров PDF/DOCX.
Стек: Python, Streamlit, PyMuPDF (fitz), Claude API (claude-sonnet-4-6), GCP Cloud Run, GCS.
Текущая версия: **v1.6 в продакшене** (pipelineAuto1 закрывает 90% типовых договоров).
Версия для разработки: **v1.7**.

## Где код

Все файлы проекта лежат в `/mnt/project/` — используй `view` для чтения перед правкой.

Текущая структура:
```
/mnt/project/
├── app.py                          # главная страница — будет ПОЛНОСТЬЮ ПЕРЕРАБОТАНА в dashboard
├── core/
│   ├── auth.py                     # check_access_code — оставляем как есть
│   ├── storage.py                  # GCS/local switch — расширяем
│   ├── parser.py                   # PDF/DOCX → fitz.Document — без изменений
│   ├── finder.py                   # regex-поиск + умный bbox — расширяем (anchor-aware)
│   ├── validator.py                # LLM-валидация — без изменений
│   ├── party_resolver.py           # LLM-резолвер стороны — без изменений
│   ├── pattern_extractor.py        # LLM-синтез regex — без изменений
│   ├── overlay.py                  # наложение PNG подписи — без изменений
│   ├── preview.py                  # рендер страниц — без изменений
│   ├── llm_finder.py               # LLM-fallback — без изменений
│   ├── language_detector.py        # без изменений
│   └── corrector.py                # без изменений
└── pages/
    ├── 1___Обучение.py             # УДАЛИТЬ
    ├── 2___Шаблоны.py              # без изменений (CRUD parties.json)
    ├── 3___Ручная_разметка.py      # УДАЛИТЬ
    ├── 4___Настройки.py            # без изменений
    └── 5_🤖_Авто_подписание.py     # ПОЛНАЯ ПЕРЕРАБОТКА под v1.7
```

После v1.7 структура должна быть:
```
/mnt/project/
├── app.py                          # dashboard
├── core/
│   ├── ... (как сейчас)
│   ├── anchor_builder.py           # НОВЫЙ — клик → текстовый якорь
│   ├── template_storage.py         # НОВЫЙ — CRUD DocumentTemplate в GCS
│   ├── fingerprint.py              # НОВЫЙ — вычисление fingerprint (для v1.8 matching)
│   └── ...
└── pages/
    ├── 2___Шаблоны.py              # без изменений
    ├── 4___Настройки.py            # без изменений
    ├── 5_🤖_Авто_подписание.py     # переработана
    └── 6_📖_Документация.py        # НОВЫЙ — рендер markdown из репо
```

## Главные принципы v1.7

### 1. Принцип якорения

Подпись в SignFinder **всегда привязана к тексту документа** — слову, фразе или линии подчёркиваний. UI не позволяет ставить подпись в пустую область страницы.

Это гарантирует переносимость шаблонов и не зависимость от абсолютных координат. Fallback на координаты **отсутствует**.

### 2. Унификация: всё через текстовые якоря

В `DocumentTemplate` нет `regex_patterns` и `manual_coordinates` отдельно. Есть **единый список `anchors`**, где каждый якорь имеет поле `added_by`:
- `auto_regex` — якорь создан из regex-паттерна автоматически
- `manual_click` — якорь создан из клика оператора

Логика применения одинакова. Различие только для отладки.

### 3. Алгоритм клик → текстовый якорь (4 уровня)

```
Уровень 1 — Текст в радиусе 30pt от клика
  Пример: клик возле "Арендатор:" → "Арендатор[\s:]+_{3,}"

Уровень 2 — Текст в той же строке  
  Пример: клик после "Исполнитель ___" → "Исполнитель[\s_]+_{3,}"

Уровень 3 — Текст в области страницы (радиус ~200pt)
  Пример: клик в углу с "М.П." рядом → "М\.П\.[\s\S]{0,200}_{3,}"

Уровень 4 — Линия подчёркиваний
  Пример: клик на "_____" без текста рядом → "_{5,}"

Нет якоря → клик не принимается, показать подсказку
```

Алгоритм идёт сверху вниз, выбирает первый подошедший. Реализация в `core/anchor_builder.py`.

## Что нужно сделать в v1.7

### Часть А. Полная переработка `app.py` (главная) в dashboard

Сейчас главная страница содержит legacy ручной флоу подписания (см. `/mnt/project/app.py`). Это всё **выпиливается** — функционал переехал в `pages/5_🤖_Авто_подписание.py`.

Новая структура `app.py`:

```
🔐 Авторизация (если ещё не вошёл — через check_access_code, как сейчас)

После авторизации показываем dashboard:

👤 Карточка подписанта
   - ФИО (из signer_profile.json)
   - Компания (из signer_profile.json)
   - Подпись (миниатюра PNG из storage.read_signature())
   - Кнопка [⚙ Изменить данные] → переход на pages/4___Настройки.py

📋 Что делаем
   - Кнопка-карточка [🤖 Автоподписание договоров] → переход на pages/5_🤖_Авто_подписание.py
   - Кнопка-карточка [⚙ Шаблоны сторон] → переход на pages/2___Шаблоны.py

📖 Документация
   - Ссылка [Концепция проекта] → pages/6_📖_Документация.py?doc=concept
   - Ссылка [Техническое задание v1.7] → pages/6_📖_Документация.py?doc=tz
```

Авторизация остаётся как сейчас в существующем `app.py` (`check_access_code` через `core/auth.py`).

### Часть Б. Удаление legacy страниц

Физически удалить из репозитория:
- `pages/1___Обучение.py` (старый эксперимент по обучению паттернам)
- `pages/3___Ручная_разметка.py` (старый эксперимент по координатной разметке)

### Часть В. Новый модуль `core/anchor_builder.py`

**Назначение:** конвертировать клик `(page_idx, x, y)` в текстовый якорь.

**Сигнатура:**

```python
from typing import Optional, Literal
from dataclasses import dataclass

@dataclass
class TextAnchor:
    id: str                          # uuid
    anchor_type: Literal["text_proximity", "underline_line"]
    anchor_level: int                # 1-4
    anchor_text: str                 # точный текст из документа
    position: Literal["right", "left", "below", "above", "on"]
    offset_pt: float
    generated_pattern: str           # regex для finder.py
    context_before: str              # ~50 символов до якоря для дезамбигуации
    context_after: str               # ~50 символов после
    page_hint: str                   # "first" | "last" | "any" | str(page_idx)
    added_by: Literal["auto_regex", "manual_click"]
    added_at: str                    # ISO timestamp
    bbox: tuple[float, float, float, float]  # где встанет подпись


def build_anchor_from_click(
    doc,
    page_idx: int,
    click_x: float,
    click_y: float,
    language: str
) -> Optional[TextAnchor]:
    """
    Превращает клик в TextAnchor через 4-уровневый алгоритм.
    Возвращает None если не удалось построить якорь (клик в пустоту).
    """


def build_anchor_from_regex_match(
    pattern: str,
    match_text: str,
    match_position: tuple,
    page_idx: int,
    language: str
) -> TextAnchor:
    """
    Превращает найденный regex-матч в TextAnchor.
    Используется при автоматическом поиске через finder.py.
    """


def has_anchor_at(doc, page_idx: int, x: float, y: float) -> bool:
    """
    Проверяет можно ли построить якорь в точке (для UI hover-проверки).
    Дешёвая операция — быстро возвращает bool.
    """
```

**Логика `build_anchor_from_click`:**

```python
def build_anchor_from_click(doc, page_idx, click_x, click_y, language):
    page = doc[page_idx]
    
    # Уровень 1 — точный текст в радиусе 30pt
    blocks_near = find_text_blocks_in_radius(page, click_x, click_y, radius=30)
    if blocks_near:
        return _build_anchor_level_1(blocks_near, click_x, click_y, language, page_idx, doc)
    
    # Уровень 2 — текст в той же строке (горизонтальная полоса ±10pt по y)
    blocks_same_row = find_text_blocks_same_row(page, click_x, click_y, tolerance=10)
    if blocks_same_row:
        return _build_anchor_level_2(blocks_same_row, click_x, click_y, language, page_idx, doc)
    
    # Уровень 3 — текст в области страницы (радиус 200pt)
    blocks_in_area = find_text_blocks_in_radius(page, click_x, click_y, radius=200)
    if blocks_in_area:
        return _build_anchor_level_3(blocks_in_area, click_x, click_y, language, page_idx, doc)
    
    # Уровень 4 — линия подчёркиваний
    underline = find_nearest_underline(page, click_x, click_y, max_distance=50)
    if underline:
        return _build_anchor_level_4(underline, click_x, click_y, language, page_idx, doc)
    
    return None  # клик в пустоту, якорь не построен
```

Для PyMuPDF: используй `page.get_text("blocks")` для текстовых блоков с bbox.

### Часть Г. Новый модуль `core/template_storage.py`

**Назначение:** CRUD для `DocumentTemplate` в GCS коллекции `gs://signfinder-config/templates/`.

**Структура `DocumentTemplate`:**

```python
@dataclass
class DocumentTemplate:
    template_id: str                 # uuid
    name: str
    language: str
    created_at: str
    created_by: Literal["pipeline_auto_1", "manual_enrichment"]
    
    fingerprint: dict                # будет использоваться в v1.8
    anchors: list[TextAnchor]
    synonyms_used: dict              # legal_entity, roles, signer
    
    usage_stats: dict                # times_applied, times_confirmed, times_rejected, last_used
```

**Файловое представление:** один JSON файл на шаблон в GCS, имя `{template_id}.json`.

**API:**

```python
def save_template(template: DocumentTemplate) -> str:
    """Сохраняет шаблон в GCS, возвращает template_id."""

def load_template(template_id: str) -> Optional[DocumentTemplate]:
    """Читает шаблон по ID."""

def list_templates(language: Optional[str] = None) -> list[DocumentTemplate]:
    """Список всех шаблонов, опционально с фильтром по языку."""

def delete_template(template_id: str) -> bool:
    """Удаляет шаблон, бэкап в _archive/."""

def generate_template_name(language: str, synonyms: dict = None) -> str:
    """
    Авто-генерация имени по схеме:
    pipelineAuto1_YYYY-MM-DD_HHMM_<язык>
    """
```

Использует существующий `core/storage.py` для GCS/local switch.

### Часть Д. Новый модуль `core/fingerprint.py`

**Назначение:** вычисление fingerprint документа для матчинга шаблонов (полный matching будет в v1.8, но fingerprint считаем уже при сохранении в v1.7).

**API:**

```python
def compute_fingerprint(doc, language: str) -> dict:
    """
    Возвращает:
    {
        "page_count": int,
        "total_chars": int,
        "chars_per_page": list[int],
        "header_simhash": str,       # SimHash шапки (find_header_page)
        "section_titles": list[str], # заголовки разделов
        "language": str
    }
    """

def find_header_page(doc, language: str) -> int:
    """
    Возвращает индекс страницы с реальной преамбулой (не титульный лист).
    Логика — см. концепцию раздел 6.4.1.
    """
```

Используй библиотеку `simhash` (`pip install simhash`) для SimHash.

### Часть Е. Расширение `core/finder.py` под якоря

Существующая логика regex-поиска не меняется в основе, но добавляется применение якорей:

```python
def apply_template_anchors(doc, template: DocumentTemplate) -> list[SignMatch]:
    """
    Применяет якоря из шаблона к новому документу.
    Для каждого якоря — ищет его generated_pattern в тексте,
    с учётом context_before/context_after для дезамбигуации.
    Возвращает список найденных мест с bbox.
    """
```

Это будет использоваться в v1.8 при матчинге. В v1.7 пока живёт как функция готовая к использованию.

### Часть Ж. Полная переработка `pages/5_🤖_Авто_подписание.py`

**UX-флоу:**

```
1. Загрузка документа PDF/DOCX (как сейчас)

2. Запуск pipelineAuto1 (существующая логика — определение языка, синонимов, regex-поиск)

3. После обработки — превью с пагинацией:
   
   Селектор страницы: [- N +]  (стр. N из M)
   
   Над превью текущей страницы:
   Чекбоксы для каждого найденного места на этой странице:
   ☑ #1 — auto (regex) | "Арендатор" (Уровень 1)
   ☑ #2 — auto (regex) | "Подпись:" (Уровень 1)
   ☑ #3 — manual | "М.П." (Уровень 3)
   
   Превью текущей страницы:
   - Рендер страницы PDF с наложенными подписями (использовать существующий preview.py)
   - Места с снятыми чекбоксами не отображаются как подписанные
   
4. Под превью — режим работы:
   [👁 Просмотр] (по умолчанию)
   [✏ Добавить место подписи]

5. В режиме "Добавить место подписи":
   - Mousemove → полупрозрачная рамка размера подписи следует за курсором
   - В пустой области без якоря → рамка красная/перечёркнутая
   - Клик в валидной зоне → 
     - вызов build_anchor_from_click(doc, page_idx, x, y, language)
     - если якорь построен → подпись фиксируется в позиции рамки
     - якорь добавляется в st.session_state["manual_anchors"]
   - Drag размещённой подписи → подпись перетаскивается, якорь пересчитывается
   - Клик по подписи + кнопка "Удалить" → удаление якоря из сессии

6. Общие действия (под превью, видны всегда):
   Всего мест: {N} auto + {M} manual = {N+M}
   
   [⬇ Скачать подписанный PDF]
   
   [💾 Сохранить шаблон]
     - Кнопка активна всегда
     - Если есть manual якоря — рекомендуется ярко (типа filled button)
     - Если только auto — стандартная (можно сохранить если хочется)
     - Имя шаблона: автогенерация через template_storage.generate_template_name(), 
       редактируемое в input поле над кнопкой
```

**Реализация drag&drop:**

Базовый `streamlit-image-coordinates` даёт только клики, для drag&drop нужен **`streamlit-drawable-canvas`** (`pip install streamlit-drawable-canvas`).

Документация: https://github.com/andfanilo/streamlit-drawable-canvas

Использовать в режиме `drawing_mode="transform"` с предустановленными прямоугольниками для каждой подписи. Изменения геометрии — это и есть drag (canvas возвращает JSON со всеми объектами и их обновлёнными координатами).

**Псевдокод интеграции:**

```python
from streamlit_drawable_canvas import st_canvas

# Получили список найденных мест и manual якорей для текущей страницы
all_anchors_for_page = [...]

# Преобразуем в формат initial_drawing для canvas
initial_objects = [
    {
        "type": "rect",
        "left": anchor.bbox[0],
        "top": anchor.bbox[1],
        "width": anchor.bbox[2] - anchor.bbox[0],
        "height": anchor.bbox[3] - anchor.bbox[1],
        "fill": "rgba(0, 255, 0, 0.3)",
        "stroke": "green",
        "id": anchor.id
    }
    for anchor in all_anchors_for_page
]

canvas_result = st_canvas(
    fill_color="rgba(0, 255, 0, 0.3)",
    background_image=page_pil_image,
    drawing_mode="transform" if mode == "edit" else "rect",
    initial_drawing={"objects": initial_objects, "version": "4.4.0"},
    update_streamlit=True,
    key=f"canvas_page_{page_idx}"
)

# Обработка изменений
if canvas_result.json_data and canvas_result.json_data["objects"]:
    for obj in canvas_result.json_data["objects"]:
        # Обновление координат якоря, пересчёт якоря если drag
        ...
```

### Часть З. Новая страница `pages/6_📖_Документация.py`

**Назначение:** список markdown-файлов из репозитория с рендером через `st.markdown()`.

**Реализация:**

```python
import streamlit as st
from pathlib import Path

DOCS_DIR = Path(__file__).parent.parent / "docs"

st.title("📖 Документация")

# Список доступных документов
docs = {
    "concept": ("Концепция проекта v1.3", "SignFinder_Concept_v1_3.md"),
    "tz": ("Техническое задание v1.7", "TZ_SignFinder_MVP_v1_7.md"),
}

# Селектор документа (опционально из query params)
selected = st.selectbox("Выберите документ", list(docs.keys()), format_func=lambda k: docs[k][0])

# Рендер
doc_path = DOCS_DIR / docs[selected][1]
if doc_path.exists():
    st.markdown(doc_path.read_text(encoding="utf-8"))
else:
    st.error(f"Документ не найден: {doc_path}")
```

Документы должны лежать в `/mnt/project/docs/` (создать папку), markdown файлы туда копируются при деплое.

## Зависимости

Новые в `requirements.txt`:
```
streamlit-drawable-canvas>=0.9.0
simhash>=2.1.2
```

## Формат выдачи

Для каждого изменённого/нового файла:

```
## Путь: /mnt/project/core/anchor_builder.py
## Статус: НОВЫЙ (v1.7)

<полный код файла>
```

или

```
## Путь: /mnt/project/app.py
## Статус: РЕДАКТИРУЕМ (полная переработка под dashboard v1.7)

<полный код файла>
```

или

```
## Путь: /mnt/project/pages/1___Обучение.py
## Статус: УДАЛИТЬ
```

**Обязательно указывай статус — НОВЫЙ / РЕДАКТИРУЕМ / УДАЛИТЬ.**

Не выводи файлы которые не трогал. Только изменённые/новые/удалённые.

## Стиль кода

- Короткие функции, docstring где нужен контекст
- Типы через `typing` для публичных функций
- f-string для промптов, длинные промпты — в `core/prompts.py` (если есть) или как константы
- Обработка ошибок через try/except с логированием в stderr
- Без магии, прямой код
- Streamlit `st.session_state` для хранения промежуточных результатов сессии

## Что НЕ меняй

- Деплой-конфигурацию (Dockerfile, cloudbuild.yaml)
- `core/auth.py`, `core/parser.py`, `core/storage.py` (только дополняй для template_storage)
- Структуру GCS bucket
- API ключи / env vars
- Существующий `pipelineAuto1` — он работает, расширяем только сохранение результата в виде шаблона

## Известные ограничения v1.7

- Drag&drop требует `streamlit-drawable-canvas` — если возникнут проблемы с компонентом, fallback на простое размещение без перетаскивания (но с возможностью удаления + повторного клика)
- Fingerprint вычисляется и сохраняется, но **matching и автоприменение шаблонов — это v1.8**, не v1.7
- Светофор не отображается в v1.7 (это v1.8)
- Версионирование шаблонов при коллизиях — v1.8

## Порядок реализации (предложение)

1. `core/anchor_builder.py` — алгоритм клик → якорь
2. `core/fingerprint.py` — find_header_page + compute_fingerprint
3. `core/template_storage.py` — CRUD шаблонов
4. `core/finder.py` — расширение apply_template_anchors
5. `app.py` — рефакторинг в dashboard
6. Удаление `pages/1___Обучение.py` и `pages/3___Ручная_разметка.py`
7. `pages/5_🤖_Авто_подписание.py` — полная переработка с canvas
8. `pages/6_📖_Документация.py` — новая страница
9. Тестирование вручную на реальных договорах

## Формат запросов

Когда пишешь — кратко, по делу, циничный delivery-manager тон. Без "отличной работы" и "всё готово к использованию". Если нужна правка от меня — конкретно что и зачем. Если предлагаешь альтернативу — с аргументацией.

---

**Текущая задача:** реализация v1.7 anchor-based templates.
**Готов отвечать на уточняющие вопросы перед началом кодинга.**
