# Промпт: SignFinder v1.8 — Светофор и узнавание похожих документов

Проект: SignFinder MVP — система автоподписания договоров PDF/DOCX.
Стек: Python, Streamlit, PyMuPDF (fitz), Claude API (claude-sonnet-4-6), GCP Cloud Run, GCS.
Версия в продакшене: v1.7 (anchor-based templates работают).
Версия для разработки: **v1.8**.

## Контекст

В v1.7 уже сделано:
- `core/anchor_builder.py` — клик → текстовый якорь (4 уровня)
- `core/template_storage.py` — CRUD `DocumentTemplate` в GCS (`gs://signfinder-config/templates/`)
- `core/fingerprint.py` — `find_header_page` + `compute_fingerprint`
- `core/finder.py` — расширен `apply_template_anchors` и `regex_match_to_anchor`
- `pages/5_🤖_Авто_подписание.py` — pipelineAuto1 + ручная доразметка + сохранение шаблонов
- В реестре `templates/` накапливаются шаблоны с fingerprint и якорями

**v1.8 добавляет следующий слой логики:** при загрузке нового документа сначала ищем похожий шаблон в реестре. Если нашли с высокой уверенностью — применяем все его якоря без полного pipelineAuto1. Если не нашли или уверенность низкая — fallback на полный пайплайн как в v1.7.

## Где код

`/mnt/project/` — используй `view` для чтения существующих файлов перед правкой.

## Главные принципы v1.8

### 1. Бинарный светофор для UI

- **🟢 Зелёный** (score ≥ 0.95): шаблон найден с высокой уверенностью → автоматическое применение всех якорей шаблона → пользователь видит готовый результат с возможностью подтвердить или вмешаться
- **🟡 Жёлтый** (любое сомнение): шаблон не найден / score низкий / коллизия двух шаблонов → запуск полного pipelineAuto1 как в v1.7

**Внутри** алгоритм считает полный score 0.0-1.0 и логирует все детали. UI показывает только два цвета.

### 2. Девиз: «Сомневаешься — спроси»

При любой неопределённости — светофор жёлтый. При коллизии двух близких шаблонов (разница score < 0.05) — спрашиваем оператора.

### 3. Каскадная стратегия матчинга

```
1. Быстрая отсечка (мгновенно)
   - page_count в пределах ±2
   - total_chars в пределах ±20%
   - language совпадает
   → Отсекает 95% несовпадений за миллисекунды

2. SimHash шапки (дёшево)
   - similarity > 0.85
   → Различает контрагентов

3. Сравнение структуры разделов (дёшево)
   - Jaccard similarity по section_titles >= 0.8

4. Композитный score
   - score = 0.4 * simhash + 0.3 * jaccard + 0.2 * cosine(chars_per_page) + 0.1 * page_count_match
```

### 4. Учёт синонимов стороны

**Критическое правило:** если синонимы нашей стороны в новом документе (определённые через текущий pipelineAuto1) не пересекаются с `synonyms_used` шаблона — это сильный сигнал к жёлтому светофору, даже при высоком fingerprint score.

## Задачи v1.8

### Часть А. Новый модуль `core/template_matcher.py`

**Назначение:** поиск похожего шаблона в реестре по fingerprint и синонимам.

**API:**

```python
from typing import Optional, Literal
from dataclasses import dataclass

@dataclass
class MatchResult:
    template_id: str
    template_name: str
    score: float
    score_breakdown: dict       # { "simhash": 0.95, "jaccard": 0.89, ... }
    explanation: str            # человеческое объяснение
    synonyms_match: bool        # пересеклись ли синонимы стороны
    

@dataclass
class MatcherResult:
    traffic_light: Literal["green", "yellow"]
    best_match: Optional[MatchResult]
    all_candidates: list[MatchResult]  # топ-5 кандидатов для drill-down
    explanation: str
    

def find_matching_templates(
    doc,                           # fitz.Document
    language: str,
    our_synonyms: Optional[dict] = None,  # синонимы нашей стороны если уже известны
    fingerprint: Optional[dict] = None,    # если уже посчитан в v1.7
) -> MatcherResult:
    """
    Главная функция матчинга.
    
    Шаги:
    1. Если fingerprint не передан — вычисляет через core.fingerprint.compute_fingerprint
    2. Загружает список шаблонов через template_storage.list_templates(language)
    3. Применяет каскадную стратегию (быстрая отсечка → simhash → jaccard → score)
    4. Сортирует кандидатов по убыванию score
    5. Если our_synonyms передан — для каждого кандидата сверяет с synonyms_used,
       снижает score если не пересекаются
    6. Определяет светофор по best_match.score
    7. Формирует объяснение
    """


def compute_composite_score(
    new_fingerprint: dict,
    template_fingerprint: dict
) -> tuple[float, dict]:
    """
    Возвращает (score, breakdown).
    
    Формула:
    score = 0.4 * simhash_similarity(new.header_simhash, tpl.header_simhash)
          + 0.3 * jaccard_similarity(new.section_titles, tpl.section_titles)
          + 0.2 * cosine_similarity(normalize(new.chars_per_page), normalize(tpl.chars_per_page))
          + 0.1 * (1 - abs(new.page_count - tpl.page_count) / max(new.page_count, tpl.page_count))
    
    breakdown = {
        "simhash": float,
        "jaccard": float,
        "cosine_chars_per_page": float,
        "page_count_similarity": float
    }
    """


def passes_quick_filter(
    new_fingerprint: dict,
    template_fingerprint: dict
) -> bool:
    """
    Быстрая отсечка:
    - language совпадает
    - |page_count_diff| <= 2
    - 0.8 <= total_chars_ratio <= 1.2
    """


def build_explanation(
    match: MatchResult,
    traffic_light: str
) -> str:
    """
    Формирует человеческое объяснение типа:
    "Шапка договора почти идентична (95%).
     Структура разделов совпадает 9/10.
     Размер документа совпадает: 12 страниц.
     Применялся успешно 4 раза."
    """
```

**Алгоритм формирования explanation (детально):**

```python
def build_explanation(match, traffic_light):
    parts = []
    
    # SimHash шапки
    sh = match.score_breakdown["simhash"]
    if sh >= 0.95:
        parts.append("Шапка договора почти идентична")
    elif sh >= 0.85:
        parts.append(f"Шапка договора очень похожа ({int(sh*100)}%)")
    elif sh >= 0.70:
        parts.append(f"Шапка договора частично совпадает ({int(sh*100)}%)")
    else:
        parts.append(f"Шапка договора отличается (совпадение {int(sh*100)}%)")
    
    # Структура разделов
    j = match.score_breakdown["jaccard"]
    if j >= 0.9:
        parts.append("структура разделов идентична")
    elif j >= 0.7:
        parts.append(f"структура разделов совпадает на {int(j*100)}%")
    else:
        parts.append(f"структура разделов отличается ({int(j*100)}% совпадения)")
    
    # Объём
    pc = match.score_breakdown["page_count_similarity"]
    if pc >= 0.95:
        parts.append("количество страниц совпадает")
    else:
        # Можно вычислить разницу страниц если передавать в breakdown
        parts.append("количество страниц немного отличается")
    
    # Синонимы
    if not match.synonyms_match:
        parts.append("⚠ синонимы стороны в этом документе отличаются от шаблона")
    
    return ". ".join(parts) + "."
```

**Граничные случаи:**

- Если в реестре `templates/` нет шаблонов → возврат `MatcherResult(traffic_light="yellow", best_match=None, ...)` с explanation «Шаблонов в реестре пока нет»
- Если несколько кандидатов с близким score (разница ≤ 0.05) — оба показываются как `all_candidates`, светофор жёлтый для решения оператора
- Если best_match.score ≥ 0.95 но `synonyms_match=False` — светофор жёлтый, explanation предупреждает об этом

### Часть Б. Новый модуль `core/traffic_light.py`

**Назначение:** классификация по светофору с настраиваемыми порогами.

```python
from typing import Literal
from dataclasses import dataclass

@dataclass
class TrafficLightConfig:
    green_threshold: float = 0.95
    synonym_match_required: bool = True  # требовать совпадения синонимов для зелёного
    

def classify(
    score: float,
    synonyms_match: bool,
    has_collision: bool = False,
    config: Optional[TrafficLightConfig] = None
) -> Literal["green", "yellow"]:
    """
    Определяет цвет светофора.
    
    Зелёный требует ВСЕ условия:
    - score >= green_threshold
    - synonyms_match == True (если synonym_match_required)
    - has_collision == False
    
    Иначе → жёлтый.
    """


def load_config() -> TrafficLightConfig:
    """
    Загружает конфигурацию из gs://signfinder-config/traffic_light_config.json.
    Если файла нет — возвращает дефолтную.
    """


def save_config(config: TrafficLightConfig) -> None:
    """Сохраняет конфигурацию в GCS."""
```

### Часть В. Расширение `core/template_storage.py`

Добавить функции для обновления `usage_stats`:

```python
def update_usage_stats(
    template_id: str,
    event: Literal["applied", "confirmed", "rejected"]
) -> None:
    """
    Обновляет статистику использования шаблона.
    
    Логика:
    - applied: times_applied++, last_used = now
    - confirmed: times_confirmed++ (оператор подтвердил что шаблон правильный)
    - rejected: times_rejected++ (оператор отверг шаблон)
    """


def add_anchors_to_template(
    template_id: str,
    new_anchors: list,            # list[TextAnchor]
    increment_version: bool = False
) -> None:
    """
    Добавляет якоря к существующему шаблону.
    Используется когда оператор расширяет шаблон новыми ручными якорями.
    
    Если increment_version=True — создаёт новую запись с suffix "_v2" вместо обновления.
    Используется при коллизиях (Q5 концепции).
    """
```

### Часть Г. Применение шаблона на странице Авто-подписание

Расширить `pages/5_🤖_Авто_подписание.py`:

**После загрузки документа, ДО запуска pipelineAuto1:**

```python
# Шаг 0: Поиск похожего шаблона
from core.template_matcher import find_matching_templates
from core.traffic_light import classify

with st.spinner("Ищу похожий шаблон в реестре..."):
    matcher_result = find_matching_templates(doc, language)

if matcher_result.traffic_light == "green":
    # Зелёный — автоматическое применение шаблона
    _show_green_light_ui(matcher_result.best_match)
    _apply_template_and_show_preview(matcher_result.best_match.template_id, doc)
else:
    # Жёлтый — запуск pipelineAuto1 как в v1.7
    if matcher_result.best_match:
        _show_yellow_light_ui(matcher_result)
    else:
        st.info("📄 Похожих шаблонов в реестре нет. Запускаю полный анализ...")
    
    _run_full_pipeline_auto_1(doc)  # существующая логика v1.7
```

**UI для зелёного света:**

```
🟢 Найден похожий шаблон

   "Аренда офиса Ромашка v1" (совпадение 96%)
   ✓ Шапка договора почти идентична
   ✓ Структура разделов совпадает 9/9
   ✓ Размер документа совпадает: 12 страниц
   ℹ Применялся успешно 4 раза за последний месяц
   
   [▶ Применить шаблон автоматически]  ← по умолчанию активирован
   [✗ Не применять, запустить полный анализ]
```

При нажатии «Применить»:
1. Загружаем шаблон через `template_storage.load_template()`
2. Применяем каждый якорь через `core.finder.apply_template_anchors(doc, template)`
3. Получаем `list[SignMatch]` с bbox
4. Конвертируем в `TextAnchor` объекты с `added_by="auto_regex"` (так как они из шаблона)
5. Сохраняем в `st.session_state["all_anchors"]`
6. Обновляем статистику: `update_usage_stats(template_id, "applied")`
7. Рендерим страницу автоподписания как в v1.7 (с пагинацией, чекбоксами, режимом доразметки)

**UI для жёлтого света с найденным шаблоном:**

```
🟡 Найден похожий шаблон, но есть отличия

   "Аренда офиса Ромашка v1" (совпадение 78%)
   ✓ Шапка совпадает
   ⚠ Структура разделов: совпало 8/10
   ⚠ Количество страниц: 14 (в шаблоне 12)
   
   [▶ Применить шаблон с проверкой] 
   [▶ Запустить полный анализ]
   [Показать все кандидаты (3)]
```

При нажатии «Применить с проверкой»:
- Применяется шаблон как в зелёном кейсе
- НО результаты помечаются как требующие проверки оператора
- После применения — обязательная фаза просмотра и доразметки (как в v1.7)

**UI для жёлтого света с коллизией:**

Если `all_candidates` содержит ≥2 шаблонов с близкими score:

```
🟡 Найдено несколько похожих шаблонов

   "Аренда офиса Ромашка v1" (78%)
   "Аренда склада Лютик v2" (75%)
   
   Рекомендуется запустить полный анализ.
   
   [▶ Полный анализ] [Использовать Ромашка] [Использовать Лютик]
```

### Часть Д. Обработка обновления шаблона (Q5 из концепции)

Если после применения шаблона оператор добавил новые ручные якоря — при сохранении показываем диалог:

```
Шаблон "Аренда офиса Ромашка v1" был расширен новыми якорями.

Что делать?
[💾 Обновить существующий шаблон] (добавить якоря в текущий)
[🆕 Создать новую версию] (сохранить как "Ромашка v2")
[✗ Не сохранять]
```

Логика:
- **Обновить** → `add_anchors_to_template(template_id, new_manual_anchors, increment_version=False)`
- **Создать новую версию** → `add_anchors_to_template(..., increment_version=True)`
- **Не сохранять** → ничего не делаем

### Часть Е. Логирование решений

Добавить логирование каждого решения матчера в `logs/traffic_light.jsonl` (локально). Для GCP Cloud Run использовать stdout/stderr — Cloud Logging автоматом подхватит.

```python
import json
import sys
from datetime import datetime, timezone

def log_matching_decision(matcher_result, doc_filename):
    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "doc_filename": doc_filename,
        "traffic_light": matcher_result.traffic_light,
        "best_score": matcher_result.best_match.score if matcher_result.best_match else None,
        "best_template_id": matcher_result.best_match.template_id if matcher_result.best_match else None,
        "candidates_count": len(matcher_result.all_candidates),
        "explanation": matcher_result.explanation
    }
    print(f"[TRAFFIC_LIGHT] {json.dumps(record, ensure_ascii=False)}", file=sys.stderr)
```

### Часть Ж. UI для настройки порогов светофора (опционально)

В `pages/4___Настройки.py` добавить раздел:

```
🚦 Светофор шаблонов

Порог зелёного: [0.95] (от 0.5 до 1.0)
Требовать совпадение синонимов для зелёного: [☑]

[💾 Сохранить]
```

Сохраняет в `traffic_light_config.json` в GCS через `traffic_light.save_config()`.

## Зависимости

В `requirements.txt` ничего нового — все нужные библиотеки уже есть из v1.7 (`simhash`, и т.д.).

## Что НЕ делаем в v1.8

- Не делаем bulk-загрузку нескольких документов (это v1.9)
- Не делаем ретенцию шаблонов (это v1.9)
- Не делаем сводную таблицу всех обработанных документов (это v1.9)
- Не трогаем `app.py` (dashboard остаётся как есть)
- Не трогаем существующие модули `parser.py`, `validator.py`, `overlay.py`, `preview.py`

## Формат выдачи

Для каждого изменённого/нового файла:

```
## Путь: /mnt/project/core/template_matcher.py
## Статус: НОВЫЙ (v1.8)

<полный код файла>
```

```
## Путь: /mnt/project/pages/5_🤖_Авто_подписание.py
## Статус: РЕДАКТИРУЕМ (расширение под v1.8 — поиск шаблона перед запуском pipelineAuto1)

<полный код файла>
```

**Обязательно указывай статус — НОВЫЙ или РЕДАКТИРУЕМ.**

Не выводи файлы которые не трогал.

## Порядок реализации (предложение)

1. `core/traffic_light.py` — простой модуль, идём первым
2. `core/template_matcher.py` — основная логика матчинга
3. Расширение `core/template_storage.py` — update_usage_stats и add_anchors_to_template
4. Расширение `pages/5_🤖_Авто_подписание.py` — интеграция матчера в флоу
5. Опционально: расширение `pages/4___Настройки.py` для порогов

## Стиль кода

- Короткие функции, docstring где нужен контекст
- Типы через `typing` для публичных функций
- f-string для логов
- Обработка ошибок через try/except с логированием в stderr
- Без магии, прямой код
- Streamlit `st.session_state` для хранения промежуточных результатов сессии

## Известные ограничения v1.8

- Если в реестре `templates/` нет шаблонов (только начали накапливать) — матчер всегда возвращает жёлтый, запускается полный pipelineAuto1
- Версионирование шаблонов простое — `_v2`, `_v3` через суффикс в имени, без сложной иерархии
- Логи решений матчера пишутся в stderr (Cloud Logging автоматом подхватит на Cloud Run, для локали — в файл)
- Калибровка порогов светофора (0.95 — стартовый) делается вручную через UI в Настройках
- Эффект применения шаблона измеряется через `usage_stats` (times_confirmed / times_applied)

## Формат запросов

Когда пишешь — кратко, по делу, циничный delivery-manager тон. Без "отличной работы". Если нужна правка от меня — конкретно что и зачем.

---

**Текущая задача:** реализация v1.8 — светофор и узнавание похожих документов.
**Готов отвечать на уточняющие вопросы перед началом кодинга.**
