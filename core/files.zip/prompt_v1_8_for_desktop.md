# SignFinder v1.8 — Светофор и узнавание похожих документов

## Обязательный первый шаг

**Прежде чем что-либо писать или редактировать:**

1. Прочитай `pages/5_🤖_Авто_подписание.py` целиком через `read_file`
2. В ответе перечисли:
   - Все функции в файле (имя + назначение в одну строку)
   - Все UI-блоки в порядке появления (с заголовками которые видит пользователь)
   - Все ключевые переменные `st.session_state` (имя + что в них)
   - Где именно в коде расположен вызов pipelineAuto1
3. Прочитай `core/template_storage.py` и опиши какие функции уже есть
4. Прочитай `core/finder.py` и опиши какие функции уже есть, в частности `apply_template_anchors` и `regex_match_to_anchor`
5. Дождись от меня подтверждения **"список полный, продолжай"**
6. **Только после этого** приступай к задаче

Это критично. Предыдущая попытка v1.8 переписала файл целиком и снесла v1.7 UI. Этого больше не должно случиться.

## Контекст версии

В v1.7 уже реализовано и работает:
- `core/anchor_builder.py` — клик → текстовый якорь (4 уровня)
- `core/template_storage.py` — CRUD `DocumentTemplate` в GCS (`gs://signfinder-config/templates/`)
- `core/fingerprint.py` — `find_header_page` + `compute_fingerprint`
- `core/finder.py` — `apply_template_anchors` и `regex_match_to_anchor`
- `pages/5_🤖_Авто_подписание.py` — pipelineAuto1 + ручная доразметка кликом + drag&drop канвас + сохранение шаблона
- В реестре `templates/` накапливаются шаблоны с fingerprint и якорями

v1.8 добавляет следующий слой логики: **при загрузке нового документа сначала ищем похожий шаблон в реестре**. Если нашли с высокой уверенностью — применяем все его якоря без запуска полного pipelineAuto1. Если не нашли или уверенность низкая — fallback на полный пайплайн (как в v1.7).

## Главные принципы v1.8

### Бинарный светофор для UI

- **🟢 Зелёный** (score ≥ 0.95): шаблон найден с высокой уверенностью → автоматическое применение всех якорей шаблона → пользователь видит готовый результат
- **🟡 Жёлтый** (любое сомнение): шаблон не найден, score низкий, коллизия двух шаблонов, синонимы не совпадают → запуск полного pipelineAuto1 как в v1.7

Внутри алгоритм считает полный score 0.0-1.0 и логирует все детали. UI показывает только два цвета.

### Девиз: «Сомневаешься — спроси»

При любой неопределённости — светофор жёлтый. При коллизии двух близких шаблонов (разница score < 0.05) — спрашиваем оператора.

### Каскадная стратегия матчинга

```
1. Быстрая отсечка (мгновенно)
   - page_count в пределах ±2
   - total_chars в пределах ±20%
   - language совпадает
   → Отсекает 95% несовпадений за миллисекунды

2. SimHash шапки (дёшево)
   - similarity > 0.85
   → Различает контрагентов

3. Сравнение структуры разделов (дёшево)
   - Jaccard similarity по section_titles >= 0.8

4. Композитный score
   - score = 0.4 * simhash + 0.3 * jaccard + 0.2 * cosine(chars_per_page) + 0.1 * page_count_match
```

### Учёт синонимов стороны (критическое правило)

Если синонимы нашей стороны в новом документе (определённые через текущий pipelineAuto1) **не пересекаются** с `synonyms_used` шаблона — это сильный сигнал к жёлтому светофору, даже при высоком fingerprint score.

## Задачи v1.8 — расширение, не переписывание

### Часть А. Новый модуль `core/template_matcher.py` (полностью новый файл)

**Назначение:** поиск похожего шаблона в реестре по fingerprint и синонимам.

**API:**

```python
from typing import Optional, Literal
from dataclasses import dataclass

@dataclass
class MatchResult:
    template_id: str
    template_name: str
    score: float
    score_breakdown: dict       # { "simhash": 0.95, "jaccard": 0.89, ... }
    explanation: str            # человеческое объяснение
    synonyms_match: bool        # пересеклись ли синонимы стороны


@dataclass
class MatcherResult:
    traffic_light: Literal["green", "yellow"]
    best_match: Optional[MatchResult]
    all_candidates: list        # топ-5 кандидатов для drill-down
    explanation: str


def find_matching_templates(
    doc,                           # fitz.Document
    language: str,
    our_synonyms: Optional[dict] = None,  # синонимы нашей стороны если уже известны
    fingerprint: Optional[dict] = None,    # если уже посчитан
) -> MatcherResult:
    """
    Главная функция матчинга.
    
    Шаги:
    1. Если fingerprint не передан — вычисляет через core.fingerprint.compute_fingerprint
    2. Загружает список шаблонов через template_storage.list_templates(language)
    3. Применяет каскадную стратегию (быстрая отсечка → simhash → jaccard → score)
    4. Сортирует кандидатов по убыванию score
    5. Если our_synonyms передан — для каждого кандидата сверяет с synonyms_used,
       снижает score если не пересекаются
    6. Определяет светофор по best_match.score
    7. Формирует объяснение
    """


def compute_composite_score(
    new_fingerprint: dict,
    template_fingerprint: dict
) -> tuple[float, dict]:
    """
    Возвращает (score, breakdown).
    
    Формула:
    score = 0.4 * simhash_similarity(new.header_simhash, tpl.header_simhash)
          + 0.3 * jaccard_similarity(new.section_titles, tpl.section_titles)
          + 0.2 * cosine_similarity(normalize(new.chars_per_page), normalize(tpl.chars_per_page))
          + 0.1 * (1 - abs(new.page_count - tpl.page_count) / max(new.page_count, tpl.page_count))
    """


def passes_quick_filter(
    new_fingerprint: dict,
    template_fingerprint: dict
) -> bool:
    """
    Быстрая отсечка:
    - language совпадает
    - |page_count_diff| <= 2
    - 0.8 <= total_chars_ratio <= 1.2
    """


def build_explanation(
    match: MatchResult,
    traffic_light: str
) -> str:
    """
    Формирует человеческое объяснение типа:
    "Шапка договора почти идентична (95%).
     Структура разделов совпадает 9/10.
     Размер документа совпадает: 12 страниц.
     Применялся успешно 4 раза."
    """
```

**Алгоритм формирования explanation:**

```python
def build_explanation(match, traffic_light):
    parts = []
    
    # SimHash шапки
    sh = match.score_breakdown["simhash"]
    if sh >= 0.95:
        parts.append("Шапка договора почти идентична")
    elif sh >= 0.85:
        parts.append(f"Шапка договора очень похожа ({int(sh*100)}%)")
    elif sh >= 0.70:
        parts.append(f"Шапка договора частично совпадает ({int(sh*100)}%)")
    else:
        parts.append(f"Шапка договора отличается (совпадение {int(sh*100)}%)")
    
    # Структура разделов
    j = match.score_breakdown["jaccard"]
    if j >= 0.9:
        parts.append("структура разделов идентична")
    elif j >= 0.7:
        parts.append(f"структура разделов совпадает на {int(j*100)}%")
    else:
        parts.append(f"структура разделов отличается ({int(j*100)}% совпадения)")
    
    # Объём
    pc = match.score_breakdown["page_count_similarity"]
    if pc >= 0.95:
        parts.append("количество страниц совпадает")
    else:
        parts.append("количество страниц немного отличается")
    
    # Синонимы
    if not match.synonyms_match:
        parts.append("⚠ синонимы стороны в этом документе отличаются от шаблона")
    
    return ". ".join(parts) + "."
```

### Часть Б. Новый модуль `core/traffic_light.py` (полностью новый файл)

**Назначение:** классификация по светофору с настраиваемыми порогами.

```python
from typing import Literal, Optional
from dataclasses import dataclass

@dataclass
class TrafficLightConfig:
    green_threshold: float = 0.95
    synonym_match_required: bool = True
    collision_delta: float = 0.05  # если два кандидата с разницей < этого — коллизия


def classify(
    score: float,
    synonyms_match: bool,
    has_collision: bool = False,
    config: Optional[TrafficLightConfig] = None
) -> Literal["green", "yellow"]:
    """
    Зелёный требует ВСЕ условия:
    - score >= green_threshold
    - synonyms_match == True (если synonym_match_required)
    - has_collision == False
    
    Иначе → жёлтый.
    """


def load_config() -> TrafficLightConfig:
    """
    Загружает конфигурацию из gs://signfinder-config/traffic_light_config.json.
    Если файла нет — возвращает дефолтную.
    """


def save_config(config: TrafficLightConfig) -> None:
    """Сохраняет конфигурацию в GCS."""
```

### Часть В. Расширение `core/template_storage.py` — ТОЛЬКО ДОБАВЛЕНИЕ функций

**Не переписывай существующий файл.** Прочитай его, добавь только две новые функции:

```python
def update_usage_stats(
    template_id: str,
    event: Literal["applied", "confirmed", "rejected"]
) -> None:
    """
    Обновляет статистику использования шаблона.
    
    Логика:
    - applied: times_applied++, last_used = now
    - confirmed: times_confirmed++
    - rejected: times_rejected++
    """


def add_anchors_to_template(
    template_id: str,
    new_anchors: list,
    increment_version: bool = False
) -> Optional[str]:
    """
    Добавляет якоря к существующему шаблону.
    
    Если increment_version=True — создаёт новую запись с suffix "_v2" вместо обновления.
    Возвращает template_id (старый или новый в зависимости от increment_version).
    """
```

### Часть Г. Расширение `pages/5_🤖_Авто_подписание.py` — РАСШИРЕНИЕ, не переписывание

**КРИТИЧЕСКИ ВАЖНО:**
- Сохрани ВСЕ существующие функции v1.7
- Сохрани ВСЕ UI-блоки (пагинация, чекбоксы найденных мест, drag&drop канвас, режим доразметки кликом, сохранение шаблона)
- Сохрани ВСЕ переменные st.session_state
- Сохрани логику drag&drop канваса и пагинации

**Что добавить:**

После загрузки документа и определения языка, **ДО вызова pipelineAuto1**, добавь новый шаг — поиск похожего шаблона:

```python
# Шаг 0 (НОВЫЙ в v1.8): Поиск похожего шаблона в реестре
from core.template_matcher import find_matching_templates
from core.traffic_light import classify, load_config

with st.spinner("Ищу похожий шаблон в реестре..."):
    matcher_result = find_matching_templates(doc, language)

st.session_state["matcher_result"] = matcher_result
st.session_state["traffic_light"] = matcher_result.traffic_light

if matcher_result.traffic_light == "green":
    # Зелёный — UI с предложением применить шаблон
    _show_green_light_ui(matcher_result.best_match)
    # Если оператор согласился — применяем
    if st.session_state.get("apply_template_confirmed"):
        _apply_template_and_skip_pipeline(matcher_result.best_match.template_id, doc)
        # дальше идёт существующий UI v1.7 (пагинация, чекбоксы, canvas)
elif matcher_result.best_match:
    # Жёлтый с найденным шаблоном — UI с выбором
    _show_yellow_light_ui_with_match(matcher_result)
    # Существующий pipelineAuto1 запускается только если оператор выбрал "полный анализ"
else:
    # Жёлтый без матча — пишем что шаблонов нет, запускаем pipelineAuto1
    st.info("📄 Похожих шаблонов в реестре нет. Запускаю полный анализ...")
    _run_existing_pipeline_auto_1(doc)  # СУЩЕСТВУЮЩАЯ функция v1.7, не трогать
```

**UI для зелёного света:**

```
🟢 Найден похожий шаблон

   "Аренда офиса Ромашка v1" (совпадение 96%)
   ✓ Шапка договора почти идентична
   ✓ Структура разделов совпадает 9/9
   ✓ Размер документа совпадает: 12 страниц
   ℹ Применялся успешно 4 раза за последний месяц
   
   [▶ Применить шаблон автоматически]  
   [✗ Не применять, запустить полный анализ]
```

При нажатии «Применить»:
1. Загружаем шаблон через `template_storage.load_template()`
2. Применяем якоря через `core.finder.apply_template_anchors(doc, template)`
3. Получаем `list[SignMatch]` с bbox
4. Конвертируем в `TextAnchor` объекты с `added_by="auto_regex"` (так как они из шаблона)
5. Сохраняем в `st.session_state["all_anchors"]`
6. Обновляем статистику: `update_usage_stats(template_id, "applied")`
7. **Дальше идёт существующий UI v1.7** (пагинация, чекбоксы, canvas, drag&drop)

**UI для жёлтого света с найденным шаблоном:**

```
🟡 Найден похожий шаблон, но есть отличия

   "Аренда офиса Ромашка v1" (совпадение 78%)
   ✓ Шапка совпадает
   ⚠ Структура разделов: совпало 8/10
   ⚠ Количество страниц: 14 (в шаблоне 12)
   
   [▶ Применить шаблон с проверкой] 
   [▶ Запустить полный анализ]
   [Показать все кандидаты (3)]
```

**UI для жёлтого света с коллизией:**

Если `all_candidates` содержит ≥2 шаблонов с близкими score:

```
🟡 Найдено несколько похожих шаблонов

   "Аренда офиса Ромашка v1" (78%)
   "Аренда склада Лютик v2" (75%)
   
   Рекомендуется запустить полный анализ.
   
   [▶ Полный анализ] [Использовать Ромашка] [Использовать Лютик]
```

### Часть Д. Обработка обновления шаблона

Если после применения шаблона оператор добавил новые ручные якоря (через существующий механизм v1.7) — при сохранении показываем диалог:

```
Шаблон "Аренда офиса Ромашка v1" был расширен новыми якорями.

Что делать?
[💾 Обновить существующий шаблон] (добавить якоря в текущий)
[🆕 Создать новую версию] (сохранить как "Ромашка v2")
[✗ Не сохранять]
```

Логика:
- **Обновить** → `add_anchors_to_template(template_id, new_manual_anchors, increment_version=False)`
- **Создать новую версию** → `add_anchors_to_template(..., increment_version=True)`
- **Не сохранять** → ничего не делаем

Эту логику добавляешь в существующий блок сохранения шаблона в `pages/5_🤖_Авто_подписание.py`, **рядом с существующей кнопкой «💾 Сохранить шаблон»** — не вместо неё.

### Часть Е. Логирование решений

Каждое решение матчера логируется в stderr (Cloud Logging автоматом подхватит на Cloud Run):

```python
import json
import sys
from datetime import datetime, timezone

def log_matching_decision(matcher_result, doc_filename):
    record = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "doc_filename": doc_filename,
        "traffic_light": matcher_result.traffic_light,
        "best_score": matcher_result.best_match.score if matcher_result.best_match else None,
        "best_template_id": matcher_result.best_match.template_id if matcher_result.best_match else None,
        "candidates_count": len(matcher_result.all_candidates),
        "explanation": matcher_result.explanation
    }
    print(f"[TRAFFIC_LIGHT] {json.dumps(record, ensure_ascii=False)}", file=sys.stderr)
```

Размести функцию в `core/template_matcher.py`, вызывай из `pages/5_🤖_Авто_подписание.py` после получения `matcher_result`.

### Часть Ж. Опциональный UI настройки порогов (если время есть)

В `pages/4_⚙️_Настройки.py` добавить раздел:

```
🚦 Светофор шаблонов

Порог зелёного: [0.95] (от 0.5 до 1.0)
Требовать совпадение синонимов для зелёного: [☑]
Разница для коллизии: [0.05]

[💾 Сохранить]
```

Сохраняет через `traffic_light.save_config()`.

## Что НЕ делать

- **Не переписывать** `pages/5_🤖_Авто_подписание.py` целиком — только добавлять блоки
- Не делать bulk-загрузку нескольких документов (это v1.9)
- Не делать ретенцию шаблонов (это v1.9)
- Не делать сводную таблицу всех обработанных документов (это v1.9)
- Не трогать `app.py` (dashboard остаётся как есть)
- Не трогать `core/parser.py`, `core/validator.py`, `core/overlay.py`, `core/preview.py`, `core/anchor_builder.py`, `core/fingerprint.py`
- Не трогать `pages/2_⚙️_Шаблоны.py` без явного запроса

## Зависимости

В `requirements.txt` ничего нового — все нужные библиотеки уже есть (`simhash` из v1.7).

## Стиль кода

- Короткие функции, docstring где нужен контекст
- Типы через `typing`
- f-string для логов
- Обработка ошибок через try/except с логированием в stderr
- Без магии, прямой код
- `st.session_state` для промежуточных результатов

## Формат коммитов

Каждый функциональный кусок — отдельный коммит:
- "v1.8: core/traffic_light.py — классификатор светофора"
- "v1.8: core/template_matcher.py — каскадный матчинг"
- "v1.8: расширение template_storage.py — update_usage_stats, add_anchors"
- "v1.8: интеграция матчера в pages/5_🤖_Авто_подписание.py"
- "v1.8 stable: матчер протестирован на N документах"

## Порядок реализации (предложение)

1. Прочитать существующие файлы (часть «Обязательный первый шаг»)
2. Дождаться подтверждения от меня
3. `core/traffic_light.py` — простой модуль, идём первым
4. `core/template_matcher.py` — основная логика матчинга
5. Расширение `core/template_storage.py` — `update_usage_stats` и `add_anchors_to_template`
6. Аккуратное расширение `pages/5_🤖_Авто_подписание.py` — поиск шаблона перед pipelineAuto1
7. Опционально: расширение `pages/4_⚙️_Настройки.py` для порогов

## Известные ограничения v1.8

- Если в реестре `templates/` нет шаблонов (только начали накапливать) — матчер всегда возвращает жёлтый, запускается полный pipelineAuto1
- Версионирование шаблонов простое — `_v2`, `_v3` через суффикс в имени
- Логи решений матчера пишутся в stderr (Cloud Logging автоматом)
- Калибровка порогов светофора (0.95 — стартовый) делается вручную через UI в Настройках
- Эффект применения шаблона измеряется через `usage_stats` (times_confirmed / times_applied)

## Формат запросов

Когда пишешь — кратко, по делу, циничный delivery-manager тон. Без "отличной работы". Если нужна правка от меня — конкретно что и зачем.

---

**Задача:** реализация v1.8 — светофор и узнавание похожих документов.

**Сначала прочитай файлы, перечисли их структуру, ДОЖДИСЬ моего подтверждения. Только потом приступай к коду.**
