"""Извлечение regex-паттернов мест подписи из документа-образца через LLM.

v1.3: новый модуль для страницы "Обучение системы".
"""
import json
import os
import re

MODEL = "claude-sonnet-4-6"


def extract_patterns(
    doc,
    party_name: str,
    language: str,
    refinement: str | None = None,
    previous_result: dict | None = None,
) -> dict:
    """LLM анализирует документ-образец → возвращает regex-паттерны и места подписи.

    Параметры:
        doc           — ParsedDocument
        party_name    — название стороны (как в реестре или новая)
        language      — 'ru' / 'en' / 'pl'
        refinement    — уточнение оператора при повторном запросе
        previous_result — предыдущий ответ для контекста рефайнмента

    Возвращает dict:
        {
            "patterns":       ["regex1", ...],
            "found_locations": [{"page": 1, "line": "...", "context": "..."}, ...],
            "reasoning":      "...",
            "error":          None | "сообщение"
        }
    """
    if not os.environ.get("ANTHROPIC_API_KEY"):
        return _error("ANTHROPIC_API_KEY не задан")

    doc_text = _get_doc_text(doc, max_chars=5000)
    if not doc_text.strip():
        return _error("Не удалось извлечь текст из документа")

    try:
        return _call_llm(doc_text, party_name, language, refinement, previous_result)
    except Exception as e:
        return _error(f"LLM error: {e}")


def merge_patterns_into_json(
    json_data: dict,
    party_name: str,
    language: str,
    new_patterns: list[str],
) -> int:
    """Добавляет паттерны в json_data in-place (без дублей).

    Если сторона или языковой блок отсутствуют — создаёт.
    Возвращает количество реально добавленных паттернов.
    """
    parties = json_data.setdefault("parties", {})

    if party_name not in parties:
        parties[party_name] = {
            "display": party_name,
            "languages": {
                language: {"aliases": [], "patterns": []}
            },
            "notes": "",
        }

    party_block = parties[party_name]
    langs = party_block.setdefault("languages", {})

    if language not in langs:
        langs[language] = {"aliases": [], "patterns": []}

    existing = set(langs[language].get("patterns", []))
    added = 0
    for p in new_patterns:
        if p not in existing:
            langs[language]["patterns"].append(p)
            existing.add(p)
            added += 1

    return added


# ── Внутренние ───────────────────────────────────────────────────────────────

def _get_doc_text(doc, max_chars: int) -> str:
    buf = []
    total = 0
    for i, page in enumerate(doc.pages):
        text = page.text or ""
        header = f"\n--- Страница {i + 1} ---\n"
        chunk = header + text
        if total + len(chunk) >= max_chars:
            buf.append(chunk[: max_chars - total])
            break
        buf.append(chunk)
        total += len(chunk)
    return "\n".join(buf)


def _call_llm(
    doc_text: str,
    party_name: str,
    language: str,
    refinement: str | None,
    previous_result: dict | None,
) -> dict:
    from anthropic import Anthropic

    client = Anthropic()

    refinement_block = ""
    if refinement and previous_result:
        refinement_block = f"""
Предыдущий анализ вернул:
Паттерны: {json.dumps(previous_result.get("patterns", []), ensure_ascii=False)}
Места: {json.dumps(previous_result.get("found_locations", []), ensure_ascii=False)}

Оператор уточняет: "{refinement}"
Учти уточнение и скорректируй результат.
"""

    lang_hint = {"ru": "русском", "en": "английском", "pl": "польском"}.get(language, language)

    prompt = f"""Анализируй договор на {lang_hint} языке. Найди все места где ПОДПИСЫВАЕТ сторона "{party_name}".

Договор (фрагмент):
---
{doc_text}
---
{refinement_block}
Задача:
1. Найди все строки/блоки с местами подписи стороны "{party_name}" — НЕ упоминания в тексте.
2. Признаки места подписи: подчёркивания (___), слово "Подпись"/"Signature", скобки с ФИО, роль + линия.
3. Для каждого места составь regex-паттерн который его надёжно найдёт в тексте.

Требования к паттернам:
- Используй [\\s_]* между словом роли и подчёркиваниями
- _{3,} для линий подписи
- Без привязки к конкретным ФИО — только роли и структура
- Без ^ и $ якорей
- IGNORECASE будет применён автоматически

Верни ТОЛЬКО JSON без markdown и пояснений:
{{
  "patterns": ["паттерн1", "паттерн2"],
  "found_locations": [
    {{"page": 1, "line": "точная строка из документа", "context": "несколько слов вокруг"}}
  ],
  "reasoning": "кратко: что нашёл и почему такие паттерны"
}}"""

    resp = client.messages.create(
        model=MODEL,
        max_tokens=1500,
        messages=[{"role": "user", "content": prompt}],
    )

    raw = (resp.content[0].text or "").strip()
    raw = re.sub(r"^```(?:json)?", "", raw).strip()
    raw = re.sub(r"```$", "", raw).strip()

    data = json.loads(raw)
    data["error"] = None
    return data


def _error(msg: str) -> dict:
    return {
        "patterns": [],
        "found_locations": [],
        "reasoning": "",
        "error": msg,
    }
